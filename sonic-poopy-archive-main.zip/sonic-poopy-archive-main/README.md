# sonic poopy archive
 please credit me (PikaNoob) if you take anything from this disassembly
